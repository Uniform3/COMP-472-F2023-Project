Instructions for COMP472 Assignment 1.ipynb file,

1. In block labeled "Penguins 1. & 2.", modify the path for variables "penguin_data" and "abalone_data" to the path to a local copy of the penguins.csv and abalone.csv files respectively. 

2. For the first set of models, run all blocks of code from "Penguin 1. & 2." to "Abalone 5. (A)-(D)".

3. For each of the next 4 set of models, run blocks of code from "Penguin 4.(a)" to "Abalone 5. (A)-(D)" with the exception of the block labeled "Penguin and Abalone 5." as that would reset the arrays tracking the models' performance statistics.

4. Once the final set of models has finished executing as per step 3. above, run the final block of code labeled "Penguin and Abalone 6. Closing Block".